# This is a multithreaded TCP/IP socket server/client setup for linux operating system.
All transactions and client related information is stored locally in text files.
