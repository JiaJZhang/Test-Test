#include <stdio.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h> 
#include <stdlib.h> 
#include <netdb.h>


int main(int argc, char *argv[]) 
{ 
	int sock = 0, valread; 
	struct sockaddr_in serv_addr; 
	char buffer[1024] = {0}; 
	struct hostent *he;

	/* get client port number */
	if (argc < 3) 
	{
		fprintf(stderr,"usage: client_hostname port_number\n");
		exit(EXIT_FAILURE); 
	}
	 
	/* get the host info */
	if ((he=gethostbyname(argv[1])) == NULL) 
	{  
		herror("gethostbyname");
		exit(EXIT_FAILURE); 
	}

	/* create socket */
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{ 
		printf("\n Socket creation error \n"); 
		return -1; 
	} 

	/* generate the end point */
	serv_addr.sin_family = AF_INET; /* use IPv4 */
	serv_addr.sin_port = htons(atoi(argv[2]));  /* set port number */
	
	// Convert IPv4 and IPv6 addresses from text to binary form 
	if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	} 

	/* connect to server */
	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
	{ 
		printf("Could not connect to overseer at %s %s \n", argv[1], argv[2]); 
		return -1; 
	} 

	/* send execution request to server */
	if (argv != NULL)
	{	
		size_t i;
		for (i = 3; i < argc; i++)
		{
			strcat(buffer, argv[i]);
			if (i < argc-1)
			{
				strcat(buffer, " ");
			}		
		}
		send(sock , buffer, strlen(buffer), 0 ); 
		
		//reset
		memset(buffer, 0, sizeof(buffer));
	}
	
	return 0; 
} 
