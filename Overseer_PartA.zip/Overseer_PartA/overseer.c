#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <arpa/inet.h>
#include <string.h> 
#include <time.h>
#include <sys/wait.h>


int main(int argc, char *argv[]) 
{ 
	int server_fd, new_socket, valread; 
	struct sockaddr_in address, caddr; 
	int addrlen = sizeof(address); 
	char buffer[1024] = {0}; 
	char timebuf[128];
	pid_t process;
	pid_t child_pid;
	char delim[] = " ";
	char *params[128];
	int counter=0;
	int status;


	/* format datetime */
	time_t t = time(0);
	strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", localtime(&t));

	/* get port number for server to listen on */
	if (argc != 2)
	{
		fprintf(stderr,"usage: client port_number\n");
		exit(EXIT_FAILURE); 
	}
	
	/* generate the socket */
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
	{ 
		perror("socket failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	/* generate the end point */
	address.sin_family = AF_INET; /* use IPv4 */
	address.sin_addr.s_addr = INADDR_ANY; /* auto-fill with my IP */
	address.sin_port = htons(atoi(argv[1])); /* set port number */
	
	/* bind the socket to the end point */
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address))<0) 
	{ 
		perror("bind failed"); 
		exit(EXIT_FAILURE); 
	} 

	/* start listnening */
	if (listen(server_fd, 3) < 0) 
	{ 
		perror("listen"); 
		exit(EXIT_FAILURE); 
	} 

	/* waiting for client requests*/
	while (1)
	{
		//accept client request
		if ((new_socket = accept(server_fd, (struct sockaddr *)&caddr, (socklen_t*)&addrlen))<0) 
		{ 
			perror("accept"); 
			continue;
		} 
		printf("%s - connection received from %s\n", timebuf, inet_ntoa(caddr.sin_addr));

		//read what client sent
		valread = read( new_socket , buffer, 1024); 

		//duplicate buffer
		char buffer_copy[sizeof( buffer )];
		strcpy( buffer_copy, buffer ); 

		if (valread > 0)
		{	
			printf("%s - attempting to execute %s\n", timebuf, buffer);

			//put received arguments into array
			char *ptr = strtok(buffer_copy, delim);
			while (ptr != NULL)
			{			
				params[counter] = ptr;
				counter++;
				ptr = strtok(NULL, delim);
			}

			//arguments for requested file
			char *comlargs[counter];
			size_t i;
			for (i = 0; i < counter; i++)
			{
				comlargs[i] = params[i+1];
				if (i == counter-1)
				{
					comlargs[i] = NULL;
				}
			}

			//create child process
			process = fork();

			// fork() failed.
			if (process < 0)
			{
				perror("fork");
				return EXIT_FAILURE;
			}

			/* child process */
			if (process == 0)
			{
				execv(params[0], comlargs); // No need to check execv() return value. If it returns, it failed.
				// perror("execv");
				return EXIT_FAILURE;
			}

			//wait for child process to exit
			child_pid = wait(&status);
			if (child_pid == -1)
			{
				//perror("wait");
				return EXIT_FAILURE;
			}
			
			//check execution status
			if (WEXITSTATUS(status) == EXIT_FAILURE)
			{
				printf("%s - could not execute %s\n", timebuf, buffer);
			}
			else
			{
				printf("%s - %s has been executed with pid %lu\n", timebuf, buffer, child_pid);
				printf("%s - %lu has terminated with status code %d\n", timebuf, child_pid, WEXITSTATUS(status));
			}
		}

		//reset
		memset(buffer, 0, sizeof(buffer));
		counter = 0;
		valread = 0;
		close(new_socket);
	}

	//close socket
	close(server_fd);

	return 0; 
} 


