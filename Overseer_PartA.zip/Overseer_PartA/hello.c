/* this is demonstrate file for overseer to process, with 2 arguments could be passed - first name, last name  and return code 99 */

#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc >= 2)
    {
        printf("Hello, %s %s!\n", argv[0], argv[1]);
    }
    printf("This message is sent to stdout. In 3 seconds i will terminate with a status code 99\n");
    sleep(3);
    return 99;
}